package com.example.crm_primine

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
